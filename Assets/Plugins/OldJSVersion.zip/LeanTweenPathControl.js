﻿#pragma strict

private var lastPos:Vector3;
private var lastPosControl:Vector3[];
public var controlRef:LeanTweenPathControl[];
private var i:int;

private static var matPoints : Material;
private static var matControls : Material;

public function createMaterials() {
    if( !matPoints ) {
        matPoints = new Material(Shader.Find("GUI/Text Shader") );
        matPoints.color = Color.cyan;
        matControls = new Material(Shader.Find("GUI/Text Shader") );
        matControls.color = Color.white;
    }
}

function init( isPoint:boolean, controlRef:LeanTweenPathControl[] ){
	createMaterials();
	gameObject.renderer.material = isPoint ? matPoints : matControls;

	lastPos = transform.position;
	this.controlRef = controlRef;
	lastPosControl = new Vector3[ 2 ];
	for(i=0;i<controlRef.Length;i++){
		if(controlRef[i])
			lastPosControl[i] = controlRef[i].transform.position;
	}
}

function OnDrawGizmos(){
	if(controlRef.Length>0 && controlRef[0]){
		if(lastPosControl){
			if(lastPos!=transform.position && lastPosControl[0] == controlRef[0].transform.position){
				var diff:Vector3 = transform.position - lastPos;
				lastPos = transform.position;
				// Debug.Log("diff:"+diff);
				controlRef[0].transform.position += diff;
				lastPosControl[0] = controlRef[0].transform.position;
				if(controlRef[1]){
					controlRef[1].transform.position += diff;
					lastPosControl[1] = controlRef[1].transform.position;
				}
			}
		}

		controlRef[0].transform.LookAt( transform.position );
		if(controlRef[1])
			controlRef[1].transform.LookAt( transform.position );
	}
}
