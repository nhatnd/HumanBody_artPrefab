#pragma strict

@script AddComponentMenu("LeanTween/LeanTweenPath")

class LeanTweenPath extends MonoBehaviour {
	public var count:int;
	
	public var pts:Transform[];
	public var path:Vector3[];

	private var i:int;
	private var lastCnt:int = 1;

	public static var curveColor:Color;
	public static var lineColor:Color;

	private function init(){
		
		if(path!=null && path.Length!=0 && (pts == null || pts.Length == 0)){ // transfer over paths made with the legacy path variable
			var cnt:int = transform.childCount;
			for (i=transform.childCount-1; i>=0; i--) {
				var go:GameObject = transform.GetChild(i).gameObject;
			    DestroyImmediate( transform.GetChild(i).gameObject );
			}
			pts = new Transform[ path.Length ];
			for(i=0;i<path.Length;i++){
				if(i>3 && i%4==0){
					
				}else{
					pts[i] = createChild(i, path[i]);
				}
			}
			reset();
			path = new Vector3[0];
			lastCnt = count = 1;
		}

		if(pts == null || pts.Length == 0){ // initial creation
			pts = [createChild(0, Vector3(0,0,0)), createChild(1, Vector3(5,0,0)), createChild(2, Vector3(4,0,0)), createChild(3, Vector3(5,0,5))];
			reset();
			lastCnt = count = 1;
		}

		if(lastCnt!=count){ // A curve must have been added or subtracted
			
			if(lastCnt>count){ // remove unused points
				var diff:int = lastCnt - count;
				var k:int = diff*4;
				for (i=pts.Length-1; k>0; i--) {
					if(pts[i]){
						DestroyImmediate( pts[i].gameObject );
					}
					k--;
				}
			}
			var newPts:Transform[] = new Transform[ count * 4 ];
			for(i=0;i<newPts.Length;i++){
				if(i<pts.Length){ // transfer old points
					newPts[i] = pts[i];
				}else{ // add in a new point
					if(i%4==1){
						newPts[i] = createChild(i, newPts[i-2].position+Vector3(5,0,0));
					}else if(i%4==2){
						newPts[i] = createChild(i, newPts[i-3].position+Vector3(4,0,0));
					}else if(i%4==3){
						newPts[i] = createChild(i, newPts[i-4].position+Vector3(5,0,5));
					}
				}
			}		
			pts = newPts;
			lastCnt = count;
		}

		reset();
	}

	private function reset(){
		for(i=0;i<pts.Length;i++){
			var ct:LeanTweenPathControl[] = [];
			if(i%4==0){
				ct = [pts[i+2].gameObject.GetComponent(LeanTweenPathControl),null];
			}else if(i%4==3){
				ct = [pts[i-2].gameObject.GetComponent(LeanTweenPathControl),null];
				if(i+3<pts.Length){
					ct[1] = pts[i+3].gameObject.GetComponent(LeanTweenPathControl);
				}
			}

			if(pts[i]){
				pts[i].gameObject.GetComponent(LeanTweenPathControl).init( i%4==0||i%4==3, ct);
			}
		}
	}

	private function createChild(i:int, pos:Vector3 ):Transform{
		var go:GameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
		go.AddComponent( LeanTweenPathControl );
		var trans:Transform = go.transform;
		DestroyImmediate( go.GetComponent( BoxCollider ) );
		trans.parent = transform;
		var iMod:int = i%4;
		var isPoint:boolean = iMod==0||iMod==3;
		var type:String = isPoint ? "point" : "control";
		var ptArea:int = (iMod/2);
		if(isPoint==false){
			ptArea = i==2 ? 0 : 1;
			trans.localScale = Vector3(0.5,0.5,0.25);
		}else{
			trans.localScale = Vector3.one * 0.5;
		}
		trans.name = "path"+Mathf.Floor(i/4)+"-"+type+ptArea;
		// trans.name = "pt"+i;
		trans.localPosition = pos;
	
		return trans;
	}

	function Start () {
		init();
		for(i=0; i < pts.Length; i++){
			if(pts[i])
				pts[i].gameObject.SetActive(false);
		}
	}

	function OnDrawGizmos(){
		init();
		
		for(var i:int = 0; i < pts.Length-3; i += 4){
			var first:Vector3 = i>3 ? pts[i-1].position : pts[i].position;
			
			Gizmos.color = curveColor;
			LeanTween.drawBezierPath(first, pts[i+2].position, pts[i+1].position, pts[i+3].position);
			
			Gizmos.color = lineColor;
			Gizmos.DrawLine(first,pts[i+2].position);
			Gizmos.DrawLine(pts[i+1].position,pts[i+3].position);
		}
	}

	function get vec3():Vector3[]{
		var p:Vector3[] = new Vector3[ pts.Length ];
		for(i=0; i < p.Length; i++){
			p[i] = i>3 && i%4==0 ? pts[i-1].position : pts[i].position;
		}
		return p;
	}
}