﻿using UnityEngine;
using System.Collections;

public class LeanTweenPathControl : MonoBehaviour {

	private Vector3 lastPos;
	private Vector3[] lastPosControl;
	public LeanTweenPathControl[] controlRef;
	private int i;

	private static Material matPoints;
	private static Material matControls;

	public void createMaterials() {
	    if( !matPoints ) {
	        matPoints = new Material(Shader.Find("GUI/Text Shader") );
	        matPoints.color = Color.cyan;
	        matControls = new Material(Shader.Find("GUI/Text Shader") );
	        matControls.color = Color.white;
	    }
	}

	public void init( bool isPoint, LeanTweenPathControl[] controlRef ){
		createMaterials();
		gameObject.renderer.material = isPoint ? matPoints : matControls;

		lastPos = transform.position;
		this.controlRef = controlRef;
		lastPosControl = new Vector3[ 2 ];
		for(i=0;i<controlRef.Length;i++){
			if(controlRef[i])
				lastPosControl[i] = controlRef[i].transform.position;
		}
	}

	void OnDrawGizmos(){
		if(controlRef.Length>0 && controlRef[0]){
			if(lastPosControl!=null){
				if(lastPos!=transform.position && lastPosControl[0] == controlRef[0].transform.position){
					Vector3 diff = transform.position - lastPos;
					lastPos = transform.position;
					// Debug.Log("diff:"+diff);
					controlRef[0].transform.position += diff;
					lastPosControl[0] = controlRef[0].transform.position;
					if(controlRef[1]){
						controlRef[1].transform.position += diff;
						lastPosControl[1] = controlRef[1].transform.position;
					}
				}
			}

			controlRef[0].transform.LookAt( transform.position );
			if(controlRef[1])
				controlRef[1].transform.LookAt( transform.position );
		}
	}

}
